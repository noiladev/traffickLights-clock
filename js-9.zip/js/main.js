let elRed = document.querySelector('.red')
let elYellow = document.querySelector('.yellow')
let elGreen = document.querySelector('.green')

function remRed(){
    elRed.style.backgroundColor = '#fff'
}
function addRed(){
    elRed.style.backgroundColor = 'red'
}
function remYellow(){
    elYellow.style.backgroundColor = '#fff'
}
function addYellow(){
    elYellow.style.backgroundColor = 'yellow'
}
function remGreen(){
    elGreen.style.backgroundColor = '#fff'
}
function addGreen(){
    elGreen.style.backgroundColor = 'green'
}

let count = 0
setInterval(() => {
    count = count + 1
    if(count >=1 && count <=2 ){
        addRed()
    }else{
        remRed()
    }
    if(count == 3 || count == 6){
        addYellow()
    }else{
        remYellow()
    }
    if(count >=4 && count <=5 ){
        addGreen()
    }else{
        remGreen()
    }
    if(count >=6){
        count = 0
    }
}, 1000);